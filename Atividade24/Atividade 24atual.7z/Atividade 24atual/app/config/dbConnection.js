var sql = require('mssql')

var connSQLServer = function (){
    const sqlConfig = {
        user: 'BD2412018',
        password: '12345678fatec',
        database: 'BD', 
        server: 'apolo',  
        options: {
            encrypt: false,
            trustServerCertificate: true,
        }
    }

    return sql.connect(sqlConfig);
}


module.exports = function (){
    return connSQLServer;
}