module.exports = function(application){
    application.get('/admin/editar_professor', function(req,res){
      
        async function getProfessorPorId() {
            try {
                var id_professor = req.query.id;
   
                var connection = application.config.dbConnection;
                const pool = await connection();
   
                var professoresModel = application.models.professormodel;
   
                professoresModel.getProfessorPorId(id_professor, pool, function(error, results){
                    res.render('admin/editar_professor', { profs : results.recordset });
                });
   
            } catch (err) {
                console.log(err)
            }
        } 
   
        getProfessorPorId();
     });
   
    application.post('/professor/editar', function(req,res){
   
        async function editarProfessor(){
            try {
                var professor = req.body;
                  
                var connection = application.config.dbConnection;
                const pool = await connection();
   
                var professoresModel = application.models.professormodel;
   
            
   
                
                professoresModel.editarProfessor(professor,pool, (error, results)=>{
                    
                    
      
                     if(error){
                     console.log('Erro ao inserir no banco:' + error);
                         res.status(500).send(error);
                     } else {
                         console.log('professor editado!!!');
                         res.redirect('/admin/crud_professores');
                     }
                });
            } catch (error) {
                console.log(error);
             }
         }
         editarProfessor();
     });
  }